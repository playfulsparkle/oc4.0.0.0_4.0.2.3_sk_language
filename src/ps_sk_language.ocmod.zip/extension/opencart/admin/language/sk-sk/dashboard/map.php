<?php
// Heading
$_['heading_title']    = 'Mapa sveta';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Mapa na nástenke bola úspešne upravená!';
$_['text_edit']        = 'Upraviť mapu na nástenke';
$_['text_order']       = 'Objednávky';
$_['text_sale']        = 'Predaj';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';
$_['entry_width']      = 'Šírka';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu mapy na nástenke!';
