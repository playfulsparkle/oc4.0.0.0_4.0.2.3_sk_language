<?php
// Heading
$_['heading_title']    = 'Celkové tržby';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Nástenka s predajmi bola úspešne upravená!';
$_['text_edit']        = 'Upraviť nástenku s predajmi';
$_['text_view']        = 'Zobraziť viac...';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';
$_['entry_width']      = 'Šírka';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu predajov na nástenke!';
