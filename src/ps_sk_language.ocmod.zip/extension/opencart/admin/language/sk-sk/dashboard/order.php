<?php
// Heading
$_['heading_title']    = 'Počet objednávok';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Nástenka s objednávkami bola úspešne upravená!';
$_['text_edit']        = 'Upraviť nástenku s objednávkami';
$_['text_view']        = 'Zobraziť viac...';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';
$_['entry_width']      = 'Šírka';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu objednávok na nástenke!';
