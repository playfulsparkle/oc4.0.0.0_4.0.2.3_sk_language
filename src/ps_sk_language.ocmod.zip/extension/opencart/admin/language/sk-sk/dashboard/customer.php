<?php
// Heading
$_['heading_title']    = 'Počet zákazníkov';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Zákazníci boli úspešne upravení!';
$_['text_edit']        = 'Upraviť Nástenku Zákazníci';
$_['text_view']        = 'Zobraziť viac...';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';
$_['entry_width']      = 'Šírka';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu zákazníka na nástenke!';
