<?php
// Heading
$_['heading_title']    = 'Online návštevníci';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Nástenka s online návštevníkmi bola úspešne upravená!';
$_['text_edit']        = 'Upraviť nástenku s online návštevníkmi';
$_['text_view']        = 'Zobraziť viac...';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';
$_['entry_width']      = 'Šírka';

// Error
$_['error_permission'] = 'Upozornenie: nemáte oprávnenie na úpravu nástenky online!';
