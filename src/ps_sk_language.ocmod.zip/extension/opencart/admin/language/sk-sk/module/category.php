<?php
// Heading
$_['heading_title']    = 'Kategórie';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Úpravy modulu kategórie boli úspešne vykonané!';
$_['text_edit']        = 'Upraviť modul kategórie';

// Entry
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu modulu kategórie!';
