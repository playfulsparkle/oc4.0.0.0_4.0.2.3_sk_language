<?php
// Heading
$_['heading_title']    = 'Účet';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Úpravy modulu účtu boli úspešne vykonané!';
$_['text_edit']        = 'Upraviť modul účtu';

// Entry
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu modulu účtu!';
