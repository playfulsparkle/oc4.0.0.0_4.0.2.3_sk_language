<?php
// Heading
$_['heading_title']      = 'Bez platby';

// Text
$_['text_extension']	 = 'Rozšírenia';
$_['text_success']       = 'Úspech: Položka bez platby bola úspešne upravená!';
$_['text_edit']          = 'Upraviť platbu';

// Entry
$_['entry_order_status'] = 'Stav objednávky';
$_['entry_status']       = 'Stav';
$_['entry_sort_order']   = 'Radenie';

// Error
$_['error_permission']   = 'Upozornenie: Nemáte oprávnenie pre správu modulu bez platby!';
