<?php
// Heading
$_['heading_title']    = 'Overovacie kódy Captcha';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Overovacie kódy Captcha boli úspešne upravené!';
$_['text_edit']        = 'Upraviť overovacie kódy Captcha';

// Entry
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu overovacích kódov Captcha!';
