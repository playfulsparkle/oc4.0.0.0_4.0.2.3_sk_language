<?php 
// Heading
$_['heading_title']    = 'Za položku';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Modul bol úspešne upravený!';
$_['text_edit']        = 'Upraviť modul Za položku';

// Entry
$_['entry_cost']       = 'Cena';
$_['entry_tax_class']  = 'Daňová trieda';
$_['entry_geo_zone']   = 'Geo oblasť';
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie pre správu modulu za položku!';
