<?php
// Heading
$_['heading_title']    = 'Konvertor mien Európskej centrálnej banky';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Úpravy konvertora mien Európskej centrálnej banky boli úspešne vykonané!';
$_['text_edit']        = 'Upraviť Európsku centrálnu banku';
$_['text_support']     = 'Toto rozšírenie vyžaduje, aby bola EUR mena dostupná ako možnosť meny.';

// Entry
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu konvertora mien Európskej centrálnej banky!';
