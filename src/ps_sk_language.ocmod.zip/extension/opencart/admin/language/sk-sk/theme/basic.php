<?php
// Heading
$_['heading_title']    = 'Základná téma obchodu';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Základná téma obchodu bola úspešne upravená!';
$_['text_edit']        = 'Upraviť základnú tému obchodu';

// Entry
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu základnej témy obchodu!';
