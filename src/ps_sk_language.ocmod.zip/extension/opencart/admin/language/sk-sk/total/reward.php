<?php
// Heading
$_['heading_title']    = 'Vernostné body';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Vernostné body boli úspešne upravené!';
$_['text_edit']        = 'Upraviť body';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie ku správe vernostných bodov!';
