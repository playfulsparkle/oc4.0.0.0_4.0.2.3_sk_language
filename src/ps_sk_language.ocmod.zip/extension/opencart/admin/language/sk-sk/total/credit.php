<?php
// Heading
$_['heading_title']    = 'Kredit obchodu';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Kredit bol úspešne upravený!';
$_['text_edit']        = 'Upraviť kredit';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie pre správu kreditov!';
