<?php
// Heading
$_['heading_title']    = 'Darčekový poukaz';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Darčekový poukaz bol úspešne upravený!';
$_['text_edit']        = 'Upraviť poukaz';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie pre správu darčekového poukazu!';
