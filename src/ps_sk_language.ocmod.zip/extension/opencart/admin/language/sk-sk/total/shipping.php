<?php
// Heading
$_['heading_title']    = 'Doprava';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Doprava bola úspešne upravená!';
$_['text_edit']        = 'Upraviť dopravu';

// Entry
$_['entry_estimator']  = 'Odhad ceny dopravy';
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie pre úpravu dopravy!';
