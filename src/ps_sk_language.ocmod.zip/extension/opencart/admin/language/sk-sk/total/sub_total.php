<?php
// Heading
$_['heading_title']    = 'Medzisúčet';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Medzisúčet bol úspešne upravený!';
$_['text_edit']        = 'Upraviť medzisúčet';

// Entry
$_['entry_status']     = 'Stav';
$_['entry_sort_order'] = 'Radenie';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie pre správu medzisúčtov!';
