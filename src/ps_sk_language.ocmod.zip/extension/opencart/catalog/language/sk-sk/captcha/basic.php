<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Zadajte kód do poľa nižšie';

// Error
$_['error_captcha'] = 'Overovací kód sa nezhoduje s obrázkom!';
