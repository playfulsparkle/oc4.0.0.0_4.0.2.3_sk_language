<?php
// Heading
$_['heading_title']    = 'Za položku';

// Text
$_['text_description'] = 'Doprava za položku';