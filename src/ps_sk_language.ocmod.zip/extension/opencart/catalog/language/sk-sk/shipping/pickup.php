<?php
// Heading
$_['heading_title']    = 'Osobný odber';

// Text
$_['text_description'] = 'Osobný odber z predajne';