<?php
// Heading
$_['heading_title']    = 'Dobierka';

// Text
$_['text_description'] = 'Dobierka za dopravu';
