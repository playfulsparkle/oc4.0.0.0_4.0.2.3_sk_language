<?php
// Heading
$_['heading_title'] = 'Doprava podľa hmotnosti';

// Text
$_['text_weight']   = 'Hmotnosť:';