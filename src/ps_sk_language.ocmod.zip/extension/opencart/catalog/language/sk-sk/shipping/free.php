<?php
// Heading
$_['heading_title']    = 'Doprava zadarmo';

// Text
$_['text_description'] = 'Doprava zadarmo';