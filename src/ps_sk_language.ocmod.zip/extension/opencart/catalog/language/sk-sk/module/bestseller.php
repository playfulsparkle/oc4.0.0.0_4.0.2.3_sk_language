<?php
// Heading
$_['heading_title'] = 'Najpredávanejšie produkty';
