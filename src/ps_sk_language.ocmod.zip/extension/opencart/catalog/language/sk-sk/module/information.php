<?php
// Heading
$_['heading_title'] = 'Informácie';

// Text
$_['text_contact']  = 'Kontaktujte nás';
$_['text_sitemap']  = 'Mapa stránok';
