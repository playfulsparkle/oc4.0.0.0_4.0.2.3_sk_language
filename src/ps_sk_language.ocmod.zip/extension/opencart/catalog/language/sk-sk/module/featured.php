<?php
// Heading
$_['heading_title'] = 'Top produkty';