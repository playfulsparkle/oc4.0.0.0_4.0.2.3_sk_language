<?php
// Heading
$_['heading_title']     = 'Účet';

// Text
$_['text_register']     = 'Registrovať';
$_['text_login']        = 'Prihlásiť';
$_['text_logout']       = 'Odhlásiť sa';
$_['text_forgotten']    = 'Zabudnuté heslo';
$_['text_account']      = 'Môj účet';
$_['text_edit']         = 'Upraviť účet';
$_['text_password']     = 'Heslo';
$_['text_address']      = 'Adresár';
$_['text_wishlist']     = 'Obľúbené produkty';
$_['text_order']        = 'História objednávok';
$_['text_download']     = 'Súbory na stiahnutie';
$_['text_reward']       = 'Vernostné body';
$_['text_return']       = 'Reklamácie';
$_['text_transaction']  = 'Transakcie';
$_['text_newsletter']   = 'Novinky';
$_['text_subscription'] = 'Predplatné';
