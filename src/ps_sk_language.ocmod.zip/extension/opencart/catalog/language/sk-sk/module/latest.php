<?php
// Heading
$_['heading_title'] = 'Najnovšie produkty';