<?php
// Heading
$_['heading_title'] = 'Akciové produkty';