<?php
// Heading
$_['heading_title'] = 'Vyberte obchod';

// Text
$_['text_default']  = 'Predvolené';
$_['text_store']    = 'Vyberte prosím obchod, ktorý chcete navštíviť.';
