<?php
// Text
$_['text_total'] = 'Celkom';