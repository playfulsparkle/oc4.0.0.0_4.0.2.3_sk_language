<?php
// Text
$_['text_handling'] = 'Manipulačný poplatok';