<?php
// Text
$_['text_credit']   = 'Kredit obchodu';
$_['text_order_id'] = 'ID objednávky: #%s';
