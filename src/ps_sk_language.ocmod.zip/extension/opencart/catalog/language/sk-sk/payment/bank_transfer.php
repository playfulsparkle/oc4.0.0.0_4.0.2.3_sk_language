<?php
// Heading
$_['heading_title']    = 'Bankový prevod';

// Text
$_['text_instruction'] = 'Inštrukcie pre bankový prevod';
$_['text_description'] = 'Prosíme o prevod celkovej sumy na nižšie uvedený bankový účet.';
$_['text_payment']     = 'Vaša objednávka nebude spracovaná, kým neobdržíme platbu.';
