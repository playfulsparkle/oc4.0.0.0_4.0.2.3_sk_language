<?php
// Heading
$_['heading_title']        = 'Dobierka';

// Error
$_['error_order_id']       = 'V relácii nie je žiadne ID objednávky!';
$_['error_payment_method'] = 'Metóda platby je nesprávna!';
