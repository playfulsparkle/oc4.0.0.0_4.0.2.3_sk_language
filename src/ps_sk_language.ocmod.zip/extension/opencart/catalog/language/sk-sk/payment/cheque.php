<?php
// Heading
$_['heading_title']    = 'Šek / Poštová poukážka';

// Text
$_['text_instruction'] = 'Inštrukcie k šeku / poštovej poukážke';
$_['text_payable']     = 'Uhraďte na: ';
$_['text_address']     = 'Odoslať na adresu: ';
$_['text_payment']     = 'Vaša objednávka nebude odoslaná, kým neobdržíme platbu.';
