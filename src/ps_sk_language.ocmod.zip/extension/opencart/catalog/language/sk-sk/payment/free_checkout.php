<?php
// Heading
$_['heading_title'] = 'Bez platby';