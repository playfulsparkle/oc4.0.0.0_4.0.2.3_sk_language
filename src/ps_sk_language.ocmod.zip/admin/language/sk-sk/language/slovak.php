<?php
// Nadpis
$_['heading_title']    = 'Slovenský jazyk';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Úspešne ste upravili slovenský jazyk!';
$_['text_edit']        = 'Upraviť slovenský jazyk';

// Vstup
$_['entry_status']     = 'Stav';

// Chyba
$_['error_permission'] = 'Upozornenie: Nemáte povolenie na úpravu slovenského jazyka!';
