<?php
// Heading
$_['heading_title']     = 'Platby';

// Text
$_['text_success']      = 'Úspech: Úspešne ste upravili platby!';
$_['text_list']         = 'Zoznam platieb';

// Column
$_['column_name']       = 'Metóda platby';
$_['column_vendor']     = 'Predajca';
$_['column_status']     = 'Stav';
$_['column_sort_order'] = 'Radenie';
$_['column_action']     = 'Akcia';

// Error
$_['error_permission']  = 'Upozornenie: Nemáte oprávnenie upravovať platby!';
$_['error_extension']   = 'Upozornenie: Rozšírenie neexistuje!';
