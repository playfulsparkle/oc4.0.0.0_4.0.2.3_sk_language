<?php
// Heading
$_['heading_title']    = 'Analytika';

// Text
$_['text_success']     = 'Úspech: Údaje o analytike boli upravené!';
$_['text_list']        = 'Zoznam analytiky';

// Column
$_['column_name']      = 'Názov analytiky';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať analytiku!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
