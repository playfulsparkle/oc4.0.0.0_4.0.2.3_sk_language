<?php
// Heading
$_['heading_title']    = 'Trhoviská';

// Text
$_['text_success']     = 'Úspech: Úspešne ste upravili trhoviská!';
$_['text_list']        = 'Zoznam trhovísk';

// Column
$_['column_name']      = 'Názov trhoviska';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať trhoviská!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
