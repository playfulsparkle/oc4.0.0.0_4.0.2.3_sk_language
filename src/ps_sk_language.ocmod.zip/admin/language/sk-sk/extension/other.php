<?php
// Heading
$_['heading_title']    = 'Ostatné';

// Text
$_['text_success']     = 'Úspech: Úspešne ste upravili ostatné rozšírenie!';
$_['text_list']        = 'Zoznam ostatných';

// Column
$_['column_name']      = 'Názov ostatného';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať ostatné rozšírenie!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
