<?php
// Heading
$_['heading_title']    = 'Šablóny';

// Text
$_['text_success']     = 'Úspech: Šablóny boli úspešne upravené!';

// Column
$_['column_name']      = 'Názov šablóny';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať šablóny!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
