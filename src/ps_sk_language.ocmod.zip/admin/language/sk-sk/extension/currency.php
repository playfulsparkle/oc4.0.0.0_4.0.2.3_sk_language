<?php
// Heading
$_['heading_title']    = 'Kurzové sadzby';

// Text
$_['text_success']     = 'Úspech: Kurzové sadzby boli upravené!';
$_['text_list']        = 'Zoznam kurzových sadzieb';

// Column
$_['column_name']      = 'Názov kurzovej sadzby';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať kurzové sadzby!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
