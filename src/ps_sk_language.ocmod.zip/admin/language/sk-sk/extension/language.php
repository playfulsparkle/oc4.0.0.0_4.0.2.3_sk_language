<?php
// Heading
$_['heading_title']    = 'Jazyky';

// Text
$_['text_success']     = 'Úspech: Jazyky boli upravené!';
$_['text_list']        = 'Zoznam jazykov';

// Column
$_['column_name']      = 'Názov jazyka';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať jazyky!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
