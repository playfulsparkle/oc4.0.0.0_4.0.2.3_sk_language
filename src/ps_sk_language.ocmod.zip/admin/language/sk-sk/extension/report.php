<?php
// Heading
$_['heading_title']     = 'Správy';

// Text
$_['text_success']      = 'Úspech: Úspešne ste upravili správy!';
$_['text_list']         = 'Zoznam hlásení';

// Column
$_['column_name']       = 'Názov správy';
$_['column_status']     = 'Stav';
$_['column_sort_order'] = 'Radenie';
$_['column_action']     = 'Akcia';

// Error
$_['error_permission']  = 'Upozornenie: Nemáte oprávnenie upravovať správy!';
$_['error_extension']   = 'Upozornenie: Rozšírenie neexistuje!';
