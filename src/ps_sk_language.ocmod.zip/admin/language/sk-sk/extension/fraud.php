<?php
// Heading
$_['heading_title']    = 'Detekčný systém';

// Text
$_['text_success']     = 'Úspech: Anti-fraud systém bol úspešne upravený!';
$_['text_list']        = 'Zoznam anti-fraud systémov';

// Column
$_['column_name']      = 'Názov systému';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať anti-fraud systém!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
