<?php
// Heading
$_['heading_title']    = 'Feed';

// Text
$_['text_success']     = 'Úspech: Feedy boli upravené!';
$_['text_list']        = 'Zoznam feedov';

// Column
$_['column_name']      = 'Názov produktového feedu';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať feedy!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
