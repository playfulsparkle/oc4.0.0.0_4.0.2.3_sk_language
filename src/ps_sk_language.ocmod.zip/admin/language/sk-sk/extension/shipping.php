<?php
// Heading
$_['heading_title']     = 'Doprava';

// Text
$_['text_success']      = 'Úspech: Úspešne ste upravili dopravu!';
$_['text_list']         = 'Zoznam dopravy';

// Column
$_['column_name']       = 'Metóda dopravy';
$_['column_status']     = 'Stav';
$_['column_sort_order'] = 'Radenie';
$_['column_action']     = 'Akcia';

// Error
$_['error_permission']  = 'Upozornenie: Nemáte oprávnenie upravovať dopravu!';
$_['error_extension']   = 'Upozornenie: Rozšírenie neexistuje!';
