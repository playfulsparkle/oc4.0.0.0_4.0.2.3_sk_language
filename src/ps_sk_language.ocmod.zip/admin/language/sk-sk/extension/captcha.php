<?php
// Heading
$_['heading_title']    = 'Captcha';

// Text
$_['text_success']     = 'Úspech: Captcha boli upravené!';
$_['text_list']        = 'Zoznam captcha';

// Column
$_['column_name']      = 'Názov captcha';
$_['column_status']    = 'Stav';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie upravovať captcha!';
$_['error_extension']  = 'Upozornenie: Rozšírenie neexistuje!';
