<?php
// Heading
$_['heading_title']     = 'Celkové sumy objednávok';

// Text
$_['text_success']      = 'Úspech: Úspešne ste upravili celkové sumy!';

// Column
$_['column_name']       = 'Celkové sumy objednávok';
$_['column_status']     = 'Stav';
$_['column_sort_order'] = 'Radenie';
$_['column_action']     = 'Akcia';

// Error
$_['error_permission']  = 'Upozornenie: Nemáte oprávnenie upravovať celkové sumy!';
$_['error_extension']   = 'Upozornenie: Rozšírenie neexistuje!';
