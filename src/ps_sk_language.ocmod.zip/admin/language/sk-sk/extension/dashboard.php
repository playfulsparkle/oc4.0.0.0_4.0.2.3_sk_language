<?php
// Heading
$_['heading_title']     = 'Nástenka';

// Text
$_['text_success']      = 'Úspech: Ovládacie panely boli upravené!';
$_['text_list']         = 'Zoznam ovládacích panelov';

// Column
$_['column_name']       = 'Názov ovládacieho panela';
$_['column_width']      = 'Šírka';
$_['column_status']     = 'Stav';
$_['column_sort_order'] = 'Radenie';
$_['column_action']     = 'Akcia';

// Error
$_['error_permission']  = 'Upozornenie: Nemáte oprávnenie upravovať ovládacie panely!';
$_['error_extension']   = 'Upozornenie: Rozšírenie neexistuje!';
