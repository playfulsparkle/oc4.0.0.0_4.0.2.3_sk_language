<?php
// Text
$_['error_language'] = 'Upozornenie: Jazyk sa nedá nájsť!';