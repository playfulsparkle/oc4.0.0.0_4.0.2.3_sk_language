<?php
// Heading
$_['heading_title']          = 'OpenCart';

// Text
$_['text_notification']      = 'Oznámenia';
$_['text_notification_all']  = 'Zobraziť všetky';
$_['text_notification_none'] = 'Nie sú žiadne oznámenia';
$_['text_profile']           = 'Váš profil';
$_['text_store']             = 'Obchody';
$_['text_help']              = 'Pomoc';
$_['text_homepage']          = 'Domovská stránka';
$_['text_support']           = 'Fórum podpory';
$_['text_documentation']     = 'Dokumentácia';
$_['text_logout']            = 'Odhlásiť';