<?php
// Heading
$_['heading_title']  = 'Administrácia';

// Text
$_['text_heading']   = 'Administrácia';
$_['text_login']     = 'Zadajte vaše prihlasovacie údaje.';
$_['text_forgotten'] = 'Zabudnuté heslo';

// Entry
$_['entry_username'] = 'Používateľské meno';
$_['entry_password'] = 'Heslo';

// Button
$_['button_login']   = 'Prihlásiť';

// Error
$_['error_login']    = 'Nesúhlas s používateľským menom a/alebo heslom.';
$_['error_token']    = 'Neplatná relácia tokenu. Prosím, prihláste sa znova.';