<?php
// Heading
$_['heading_title']    = 'Oznámenia';

// Text
$_['text_success']     = 'Úspech: Úspešne ste upravili oznámenia!';
$_['text_list']        = 'Zoznam oznámení';

// Column
$_['column_message']   = 'Správa';
$_['column_action']    = 'Akcia';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na úpravu oznámení!';
