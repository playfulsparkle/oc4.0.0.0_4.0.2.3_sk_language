<?php
// Heading
$_['heading_title']    = 'Chybový protokol';

// Text
$_['text_success']     = 'Úspech: Úspešne ste vymazali svoj chybný protokol!';
$_['text_list']        = 'Zoznam chýb';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na vymazanie chybového protokolu!';
$_['error_file']       = 'Upozornenie: Súbor %s sa nedá nájsť!';
$_['error_size']       = 'Upozornenie: Súbor chybového protokolu %s je %s!';
$_['error_empty']      = 'Upozornenie: Súbor protokolu %s je prázdny!';
