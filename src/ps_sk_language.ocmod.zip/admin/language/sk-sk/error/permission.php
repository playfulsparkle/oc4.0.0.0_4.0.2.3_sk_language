<?php
// Heading
$_['heading_title']   = 'Prístup odmietnutý!';

// Text
$_['text_permission'] = 'Nemáte oprávnenie na prístup k tejto stránke! Prosím kontaktujte administrátora.';
