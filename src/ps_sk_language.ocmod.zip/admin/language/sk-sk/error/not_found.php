<?php
// Heading
$_['heading_title']  = 'Stránka nebola nájdená!';

// Text
$_['text_not_found'] = 'Stránka, ktorú hľadáte nebola nájdená! Prosím kontaktujte administrátora stránok ak problém pretrváva.';
