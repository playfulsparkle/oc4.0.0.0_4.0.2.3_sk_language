<?php
// Heading
$_['heading_title'] = 'Správy';

// Text
$_['text_success']  = 'Úspech: Úprava správ bola úspešná!';
$_['text_type']     = 'Vyberte typ správy';
$_['text_filter']   = 'Filter';
