<?php
// Text
$_['text_subject'] = '%s - Váš účet bol aktivovaný!';
$_['text_welcome'] = 'Vitajte a ďakujeme za registráciu na %s!';
$_['text_login']   = 'Váš účet bol teraz vytvorený a môžete sa prihlásiť použitím svojej emailovej adresy a hesla na našej webovej stránke alebo na nasledujúcej URL:';
$_['text_service'] = 'Po prihlásení budete mať prístup k ďalším službám vrátane prezerania predchádzajúcich objednávok, tlačenia faktúr a úpravy informácií o vašom účte.';
$_['text_thanks']  = 'Ďakujeme,';

// Button
$_['button_login'] = 'Prihlásiť sa';
