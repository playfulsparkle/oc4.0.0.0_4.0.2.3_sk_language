<?php
// Text
$_['text_subject']  = '%s - Vernostné body';
$_['text_received'] = 'Získali ste %s vernostné body!';
$_['text_total']    = 'Celkový počet vašich vernostných bodov je teraz %s.';
