<?php
// Text
$_['text_subject']             = '%s - Predplatné';
$_['text_subscription_id']     = 'ID predplatného';
$_['text_date_added']          = 'Dátum pridania predplatného:';
$_['text_subscription_status'] = 'Vaše predplatné bolo zmenené na nasledujúci stav:';
$_['text_comment']             = 'Komentáre k vášmu predplatnému sú:';
$_['text_payment_method']      = 'Spôsob platby';
$_['text_payment_code']        = 'Platobný kód';
$_['text_footer']              = 'Prosím, odpovedzte na tento e-mail, ak máte akékoľvek otázky.';
