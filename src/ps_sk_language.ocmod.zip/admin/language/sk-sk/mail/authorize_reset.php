<?php
// Text
$_['text_subject'] = 'Obnovenie pokusov o bezpečnostný kód';
$_['text_reset']   = 'Niekoľko pokusov o zadanie bezpečnostného kódu bolo nesprávnych viac než 3-krát.';
$_['text_link']    = 'Kliknite na nižšie uvedený odkaz na obnovenie zabezpečenia účtu:';
$_['text_ip']      = 'IP adresa:';
$_['text_regards'] = 'S pozdravom';
