<?php
// Text
$_['text_subject']   = '%s - Váš účet bol zamietnutý!';
$_['text_welcome']   = 'Vitajte a ďakujeme za registráciu na %s!';
$_['text_denied']    = 'Žiaľ, vaša žiadosť bola zamietnutá. Pre viac informácií môžete kontaktovať vlastníka obchodu tu:';
$_['text_thanks']    = 'Ďakujeme,';

// Button
$_['button_contact'] = 'Kontaktujte nás';
