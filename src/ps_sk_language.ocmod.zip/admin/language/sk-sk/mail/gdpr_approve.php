<?php
// Text
$_['text_subject'] = '%s - Žiadosť o GDPR bola schválená!';
$_['text_request'] = 'Žiadosť o vymazanie účtu';
$_['text_hello']   = 'Dobrý deň <strong>%s</strong>,';
$_['text_user']    = 'Užívateľ';
$_['text_gdpr']    = 'Vaša žiadosť o vymazanie údajov podľa GDPR bola schválená a bude vymazaná za <strong>%s dní</strong>.';
$_['text_q']       = 'P. Prečo vaše údaje nevymažeme okamžite?';
$_['text_a']       = 'O. Žiadosti o vymazanie účtov budú spracované po <strong>%s dňoch</strong>, aby sa mohli spracovať akékoľvek vrátenia peňazí, reklamácie alebo detekcia podvodov.';
$_['text_delete']  = 'Dostanete e-mail, keď bude váš účet vymazaný.';
$_['text_thanks']  = 'Ďakujeme,';
