<?php
// Text
$_['text_subject']   = '%s - Žiadosť o GDPR bola zamietnutá!';
$_['text_export']    = 'Žiadosť o export údajov z účtu';
$_['text_remove']    = 'Žiadosť o vymazanie účtu';
$_['text_hello']     = 'Dobrý deň <strong>%s</strong>,';
$_['text_user']      = 'Užívateľ';
$_['text_contact']   = 'Žiaľ, vaša žiadosť bola zamietnutá. Pre viac informácií môžete kontaktovať obchod tu:';
$_['text_thanks']    = 'Ďakujeme,';

// Button
$_['button_contact'] = 'Kontaktujte nás';
