<?php
// Text
$_['text_subject'] = '%s - Váš partnerský účet bol zamietnutý!';
$_['text_welcome'] = 'Vitajte a ďakujeme za registráciu na %s!';
$_['text_denied']  = 'Ľutujeme, ale vaša žiadosť bola zamietnutá. Pre viac informácií môžete kontaktovať vlastníka obchodu tu:';
$_['text_thanks']  = 'Ďakujeme,';
