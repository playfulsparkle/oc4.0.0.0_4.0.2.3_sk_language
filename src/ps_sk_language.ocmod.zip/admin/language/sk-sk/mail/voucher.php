<?php
// Text
$_['text_success']  = 'Úspech: Úspešne ste upravili poukážky!';
$_['text_subject']  = 'Bol vám zaslaný darčekový poukaz od %s';
$_['text_greeting'] = 'Gratulujeme, obdržali ste darčekový poukaz v hodnote %s';
$_['text_from']     = 'Tento darčekový poukaz vám poslal %s';
$_['text_message']  = 'S odkazom na správu';
$_['text_redeem']   = 'Ak chcete tento darčekový poukaz uplatniť, najprv si zapíšte kód na uplatnenie, ktorý je <b>%s</b>. Potom kliknite na nižšie uvedený odkaz a zakúpte produkt, na ktorý chcete tento darčekový poukaz použiť. Nakoniec môžete zadať kód darčekového poukazu na stránke <b>Košík</b> pred kliknutím na: <b>Pokladňa</b>.';
$_['text_footer']   = 'Ak máte akékoľvek otázky, odpovedzte na tento e-mail.';
$_['text_sent']     = 'Úspech: E-mail s darčekovým poukazom bol odoslaný!';
