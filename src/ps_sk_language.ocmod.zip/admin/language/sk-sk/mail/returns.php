<?php
// Text
$_['text_subject']       = '%s - Aktualizácia reklamácie %s';
$_['text_return_id']     = 'ID reklamácie:';
$_['text_date_added']    = 'Dátum reklamácie:';
$_['text_return_status'] = 'Vaša reklamácia bola aktualizovaná na nasledujúci stav:';
$_['text_comment']       = 'Komentáre k vašej reklamácii sú:';
$_['text_footer']        = 'Prosím, odpovedzte spätne na tento e-mail, ak máte akékoľvek otázky.';
