<?php
// Text
$_['text_subject']  = '%s - Váš partnerský účet bol aktivovaný!';
$_['text_welcome']  = 'Vitajte a ďakujeme za registráciu na %s!';
$_['text_login']    = 'Váš účet bol schválený a môžete sa prihlásiť pomocou svojej e-mailovej adresy a hesla navštívením našej webovej stránky alebo na nasledujúcej URL adrese:';
$_['text_service']  = 'Po prihlásení budete môcť generovať sledovacie kódy, sledovať platby provízií a upravovať informácie o svojom účte.';
$_['text_thanks']   = 'Ďakujeme,';
