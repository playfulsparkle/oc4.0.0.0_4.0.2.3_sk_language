<?php
// Text
$_['text_subject'] = 'Bezpečnosť';
$_['text_code']    = 'Musíte zadať bezpečnostný kód v administratívnej bezpečnostnej kontrole.';
$_['text_ip']      = 'IP adresa:';
$_['text_regards'] = 'S pozdravom';
