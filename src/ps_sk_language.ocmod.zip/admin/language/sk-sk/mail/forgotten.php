<?php
// Text
$_['text_subject']  = '%s - Žiadosť o resetovanie hesla';
$_['text_greeting'] = 'Bolo požiadané nové heslo pre správu %s.';
$_['text_change']   = 'Ak chcete resetovať svoje heslo, kliknite na nasledujúci odkaz:';
$_['text_ip']       = 'IP adresa použitá na túto žiadosť bola:';
