<?php
// Text
$_['text_subject']  = '%s - Partnerský kredit';
$_['text_received'] = 'Obdržali ste %s kredit!';
$_['text_total']    = 'Vaša celková výška kreditu je teraz %s.';
$_['text_credit']   = 'Váš kredit na účte môže byť odpočítaný z vášho ďalšieho nákupu.';
