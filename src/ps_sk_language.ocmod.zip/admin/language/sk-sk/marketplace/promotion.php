<?php
// Text
$_['text_recommended'] = 'Odporúčané';
$_['text_install']     = 'Inštalovať';
$_['text_uninstall']   = 'Odinštalovať';
$_['text_delete']      = 'Odstrániť';
