<?php
// Heading
$_['heading_title'] = 'Rozšírenia';

// Text
$_['text_success']  = 'Úspech: Rozšírenia boli upravené!';
$_['text_list']     = 'Zoznam rozšírení';
$_['text_type']     = 'Vyberte typ rozšírenia';
$_['text_filter']   = 'Filter';
