<?php
// Heading
$_['heading_title']     = 'Spustenie';

// Text
$_['text_success']      = 'Úspech: Spustenie boli úspešne upravené!';
$_['text_list']         = 'Zoznam modifikácií';

// Column
$_['column_code']       = 'Kód spustenie';
$_['column_sort_order'] = 'Radenie';
$_['column_action']     = 'Akcia';

// Error
$_['error_permission']  = 'Upozornenie: Nemáte povolenie upravovať spustenie!';
