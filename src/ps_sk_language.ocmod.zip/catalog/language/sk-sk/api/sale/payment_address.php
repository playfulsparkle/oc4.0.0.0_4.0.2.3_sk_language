<?php
// Text
$_['text_success']       = 'Úspech: Platobná adresa bola nastavená!';

// Error
$_['error_firstname']    = 'Meno musí mať viac ako 1 znak a menej ako 32 znakov!';
$_['error_lastname']     = 'Priezvisko musí mať viac ako 1 znak a menej ako 32 znakov!';
$_['error_address_1']    = 'Adresa 1 musí mať viac ako 3 znaky a menej ako 128 znakov!';
$_['error_city']         = 'Mesto musí mať viac ako 3 znaky a menej ako 128 znakov!';
$_['error_postcode']     = 'PSČ musí mať viac ako 2 znaky a menej ako 10 znakov pre túto krajinu!';
$_['error_country']      = 'Prosím, vyberte krajinu!';
$_['error_zone']         = 'Prosím, vyberte oblasť!';
$_['error_custom_field'] = '%s je povinné!';
$_['error_regex']        = '%s nie je platný vstup!';
