<?php
// Text
$_['text_success']  = 'Úspech: Vaša zľava na základe vernostných bodov bola uplatnená!';
$_['text_remove']   = 'Úspech: Vaša zľava na základe vernostných bodov bola odstránená!';

// Error
$_['error_reward']  = 'Upozornenie: Zadajte množstvo vernostných bodov, ktoré chcete použiť!';
$_['error_points']  = 'Upozornenie: Nemáte %s vernostných bodov!';
$_['error_maximum'] = 'Upozornenie: Maximálny počet bodov, ktorý môžete uplatniť, je %s!';
