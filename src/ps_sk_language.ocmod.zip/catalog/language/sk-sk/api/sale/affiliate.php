<?php
// Text
$_['text_success']    = 'Úspech: Provízia z partnerského programu bude uplatnená na túto objednávku!';
$_['text_remove']     = 'Úspech: Vaša provízia z partnerského programu bola odstránená!';

// Error
$_['error_affiliate'] = 'Upozornenie: Partnerský program sa nenašiel!';
