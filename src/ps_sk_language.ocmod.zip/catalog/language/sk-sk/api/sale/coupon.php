<?php
// Text
$_['text_success'] = 'Úspech: Váš zľavový kupón bol uplatnený!';
$_['text_remove']  = 'Úspech: Váš zľavový kupón bol odstránený!';

// Error
$_['error_coupon'] = 'Upozornenie: Kupón je neplatný, expirovaný alebo dosiahol svoj limit použitia!';
