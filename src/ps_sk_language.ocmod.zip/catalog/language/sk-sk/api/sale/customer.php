<?php
// Text
$_['text_success']         = 'Úspech: Úspešne ste upravili zákazníkov';

// Error
$_['error_customer']       = 'Upozornenie: Zákazník sa nenašiel!';
$_['error_customer_group'] = 'Skupina zákazníkov sa nezdá byť platná!';
$_['error_firstname']      = 'Meno musí byť dlhšie ako 1 znak a kratšie než 32 znakov!';
$_['error_lastname']       = 'Priezvisko musí byť dlhšie ako 1 znak a kratšie než 32 znakov!';
$_['error_email']          = 'E-mailová adresa sa nezdá byť platná!';
$_['error_telephone']      = 'Telefónne číslo musí byť dlhšie ako 3 znaky a kratšie než 32 znakov!';
$_['error_custom_field']   = '%s je povinné!';
$_['error_regex']          = '%s nie je platný vstup!';
