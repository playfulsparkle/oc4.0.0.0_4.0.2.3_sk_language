<?php
// Text
$_['text_success']           = 'Úspech: Doprava bola nastavená!';

// Error
$_['error_shipping_address'] = 'Upozornenie: Adresa pre dopravu je povinná!';
$_['error_shipping_method']  = 'Upozornenie: Metóda dopravy je povinná!';
$_['error_no_shipping']      = 'Upozornenie: Nie sú dostupné žiadne možnosti dopravy!';
$_['error_shipping']         = 'Upozornenie: Nie sú žiadne produkty, ktoré by vyžadovali dopravu';
