<?php
// Text
$_['text_success']          = 'Úspech: Spôsob platby bol nastavený!';

// Error
$_['error_payment_address'] = 'Upozornenie: Vyžaduje sa adresa pre platbu!';
$_['error_payment_method']  = 'Upozornenie: Vyžaduje sa spôsob platby!';
$_['error_no_payment']      = 'Upozornenie: Žiadne možnosti platby nie sú dostupné!';
$_['error_product']         = 'Upozornenie: Vyžadujú sa produkty!';
