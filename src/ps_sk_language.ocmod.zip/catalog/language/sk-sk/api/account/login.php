<?php
// Text
$_['text_success']     = 'Úspech: API relácia bola úspešne spustená!';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na prístup k API!';
$_['error_key']        = 'Upozornenie: Nesprávny API kľúč!';
$_['error_ip']         = 'Upozornenie: Vaša IP adresa %s nemá povolený prístup k tomuto API!';
