<?php
// Text
$_['text_success']   = 'Úspech: Vaša mena bola zmenená!';

// Error
$_['error_currency'] = 'Upozornenie: Mena sa nenašla!';
