<?php
// Text
$_['text_success'] = 'Úspech: Obchod bol zmenený!';

// Error
$_['error_store']  = 'Upozornenie: Obchod sa nenašiel!';
