<?php
// Heading
$_['heading_title'] = 'Požadovaná stránka nebola nájdená!';

// Text
$_['text_error']    = 'Požadovaná stránka nebola nájdená!';
