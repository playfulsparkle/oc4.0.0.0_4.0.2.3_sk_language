<?php
// Text
$_['text_price'] = 'Cena:';
$_['text_tax']   = 'Bez DPH:';
