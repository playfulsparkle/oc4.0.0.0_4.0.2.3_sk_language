<?php
// Text
$_['text_success'] = 'Ďakujeme, že ste nás informovali o svojej voľbe!';
$_['text_cookie']  = 'Táto webová stránka používa súbory cookies. Pre viac informácií <a href="%s" class="alert-link modal-link">kliknite sem</a>.';

// Button
$_['button_agree']    = 'Áno, to je v poriadku!';
$_['button_disagree'] = 'Nie, ďakujem!';
