<?php
// Text
$_['text_category']  = 'Kategórie';
$_['text_all']       = 'Zobraziť všetko';
