<?php
// Text
$_['text_information']  = 'Informácie';
$_['text_blog']         = 'Blog';
$_['text_service']      = 'Zákaznícky servis';
$_['text_extra']        = 'Extra';
$_['text_contact']      = 'Kontaktujte nás';
$_['text_return']       = 'Reklamácie';
$_['text_sitemap']      = 'Mapa stránok';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = 'Výrobcovia';
$_['text_voucher']      = 'Darčekové poukážky';
$_['text_affiliate']    = 'Partnerský progra';
$_['text_special']      = 'Akciový tovar';
$_['text_account']      = 'Môj účet';
$_['text_order']        = 'História objednávok';
$_['text_wishlist']     = 'Obľúbené produkty';
$_['text_newsletter']   = 'Novinky';
$_['text_powered']      = 'Beží na <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
