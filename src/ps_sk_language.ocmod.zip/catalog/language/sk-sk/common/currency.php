<?php
// Text
$_['text_currency'] = 'Mena';
