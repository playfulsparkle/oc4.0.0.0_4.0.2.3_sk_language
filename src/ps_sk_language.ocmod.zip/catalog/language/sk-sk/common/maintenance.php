<?php
// Heading
$_['heading_title']    = 'Údržba systému';

// Text
$_['text_maintenance'] = 'Údržba systému';
$_['text_message']     = '<h1 style="text-align:center;">V súčasnosti vykonávame pravidelnú údržbu systému. <br/>Obchod bude prístupný v čo najkratšom čase.</h1>';
