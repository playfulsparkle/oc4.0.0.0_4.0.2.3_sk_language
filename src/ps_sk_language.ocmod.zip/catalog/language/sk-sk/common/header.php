<?php
// Text
$_['text_wishlist']      = 'Obľúbené produkty (%s)';
$_['text_shopping_cart'] = 'Nákupný košík';
$_['text_account']       = 'Môj účet';
$_['text_register']      = 'Registrácia';
$_['text_login']         = 'Prihlásiť sa';
$_['text_order']         = 'História objednávok';
$_['text_transaction']   = 'Transakcie';
$_['text_download']      = 'Súbory na stiahnutie';
$_['text_logout']        = 'Odhlásiť sa';
$_['text_checkout']      = 'Pokladňa';