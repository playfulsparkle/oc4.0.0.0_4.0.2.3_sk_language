<?php
// Text
$_['text_error'] = 'Informačná stránka nebola nájdená!';
