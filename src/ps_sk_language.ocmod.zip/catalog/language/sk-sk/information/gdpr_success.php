<?php
// Heading
$_['heading_title'] = 'Úspech GDPR';

// Text
$_['text_account']  = 'Účet';
$_['text_export']   = 'Žiadosť o export vašich údajov z účtu bola prijatá.';
$_['text_remove']   = 'Žiadosti o vymazanie účtu podľa GDPR budú spracované po <strong>%s dňoch</strong>, aby mohli byť spracované všetky spätné platby, refundácie alebo detekcia podvodov.';
