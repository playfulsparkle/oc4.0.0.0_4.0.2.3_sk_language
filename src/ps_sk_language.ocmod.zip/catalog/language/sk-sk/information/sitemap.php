<?php
// Heading
$_['heading_title']    = 'Mapa stránok';

// Text
$_['text_special']     = 'Akciový tovar';
$_['text_account']     = 'Môj účet';
$_['text_edit']        = 'Informácie o účte';
$_['text_password']    = 'Heslo';
$_['text_address']     = 'Adresár';
$_['text_history']     = 'História objednávok';
$_['text_download']    = 'Súbory na stiahnutie';
$_['text_cart']        = 'Nákupný košík';
$_['text_checkout']    = 'Pokladňa';
$_['text_search']      = 'Vyhľadávanie';
$_['text_information'] = 'Informácie';
$_['text_contact']     = 'Kontaktujte nás';
