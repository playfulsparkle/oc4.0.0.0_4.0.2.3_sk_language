<?php
// Text
$_['text_subject']      = '%s - objednávka %s';
$_['text_received']     = 'Dostali ste objednávku.';
$_['text_order_id']     = 'ID objednávky:';
$_['text_date_added']   = 'Dátum pridania:';
$_['text_order_status'] = 'Stav objednávky:';
$_['text_product']      = 'Produkty:';
$_['text_total']        = 'Celkom:';
$_['text_comment']      = 'Komentáre k vašej objednávke:';
