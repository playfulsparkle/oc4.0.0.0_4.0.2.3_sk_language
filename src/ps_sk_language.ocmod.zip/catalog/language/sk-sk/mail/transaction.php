<?php
// Text
$_['text_subject']  = '%s - provízia z partnerského programu';
$_['text_received'] = 'Gratulujeme! Dostali ste platbu provízie z partnerského programu %s.';
$_['text_amount']   = 'Dostali ste:';
$_['text_total']    = 'Vaša celková suma provízie je teraz:';
