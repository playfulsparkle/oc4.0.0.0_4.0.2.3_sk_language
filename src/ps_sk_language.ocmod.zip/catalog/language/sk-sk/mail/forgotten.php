<?php
// Text
$_['text_subject']  = '%s - Žiadosť o obnovenie hesla';
$_['text_greeting'] = 'Bolo požiadané nové heslo pre účet zákazníka %s.';
$_['text_change']   = 'Ak chcete obnoviť svoje heslo, kliknite na nasledujúci odkaz:';
$_['text_ip']       = 'IP adresa použitá na vykonanie tejto žiadosti bola:';

// Button
$_['button_reset']  = 'Obnoviť heslo';
