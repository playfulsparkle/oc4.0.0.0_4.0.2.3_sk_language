<?php
// Text
$_['text_subject']  = 'Bola vám zaslaná darčeková poukážka od %s';
$_['text_greeting'] = 'Gratulujeme, dostali ste darčekovú poukážku v hodnote %s';
$_['text_from']     = 'Táto darčeková poukážka vám bola zaslaná od %s';
$_['text_message']  = 'Pripojená správa';
$_['text_redeem']   = 'Na uplatnenie tejto darčekovej poukážky si zapíšte kód na uplatnenie, ktorý je <b>%s</b>, potom kliknite na nasledujúci odkaz a zakúpte produkt, na ktorý chcete túto darčekovú poukážku použiť. Kód darčekovej poukážky môžete zadať na stránke nákupného košíka pred kliknutím na „Pokladňa“.';
$_['text_footer']   = 'Ak máte akékoľvek otázky, odpovedzte prosím na tento e-mail.';
