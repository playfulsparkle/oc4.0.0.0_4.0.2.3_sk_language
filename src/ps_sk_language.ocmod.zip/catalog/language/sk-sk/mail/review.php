<?php
// Text
$_['text_subject']  = '%s - recenzia produktu';
$_['text_waiting']  = 'Máte novú recenziu produktu čakajúcu na schválenie.';
$_['text_product']  = 'Produkt:';
$_['text_reviewer'] = 'Recenzent:';
$_['text_rating']   = 'Hodnotenie:';
$_['text_review']   = 'Text recenzie:';
