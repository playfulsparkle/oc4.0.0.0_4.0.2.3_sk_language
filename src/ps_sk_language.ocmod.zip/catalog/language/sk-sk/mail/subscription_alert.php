<?php
// Text
$_['text_subject']              = '%s - objednávka %s - zrušené predplatné';
$_['text_received']             = 'Bola prijatá žiadosť o zrušenie predplatného.';
$_['text_orders_id']            = 'ID objednávky:';
$_['text_subscription_id']      = 'ID predplatného:';
$_['text_date_added']           = 'Dátum pridania:';
$_['text_subscription_status']  = 'Stav predplatného:';
$_['text_comment']              = 'Komentáre k vašim predplatným sú:';
$_['text_canceled']             = 'Úspech: Plán predplatného bol zrušený!';
