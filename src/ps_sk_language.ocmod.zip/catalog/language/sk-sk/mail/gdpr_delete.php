<?php
// Text
$_['text_subject']   = '%s - Žiadosť o GDPR bola spracovaná!';
$_['text_request']   = 'Žiadosť o vymazanie účtu';
$_['text_hello']     = 'Ahoj <strong>%s</strong>,';
$_['text_user']      = 'Užívateľ';
$_['text_delete']    = 'Vaša žiadosť o vymazanie údajov podľa GDPR bola teraz dokončená.';
$_['text_contact']   = 'Pre viac informácií môžete kontaktovať vlastníka obchodu tu:';
$_['text_thanks']    = 'Ďakujeme,';

// Button
$_['button_contact'] = 'Kontaktujte nás';
