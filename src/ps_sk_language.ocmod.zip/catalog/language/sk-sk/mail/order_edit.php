<?php
// Text
$_['text_subject']      = '%s - aktualizácia objednávky %s';
$_['text_order_id']     = 'ID objednávky:';
$_['text_date_added']   = 'Dátum objednávky:';
$_['text_order_status'] = 'Vaša objednávka bola aktualizovaná na nasledujúci stav:';
$_['text_comment']      = 'Komentáre k vašej objednávke:';
$_['text_link']         = 'Pre zobrazenie vašej objednávky kliknite na nasledujúci odkaz:';
$_['text_footer']       = 'Prosím, odpovedzte na tento e-mail, ak máte akékoľvek otázky.';
