<?php
// Text
$_['text_points']                = 'Vernostné body';
$_['text_subscription']          = 'Predplatné';
$_['text_subscription_trial']    = '%s každé %d %s(s) na prvých %d platieb';
$_['text_subscription_duration'] = '%s každé %d %s(s) počas nasledujúcich %d platieb';
$_['text_subscription_cancel']   = '%s každé %d %s(s) až do zrušenia';
$_['text_day']                   = 'deň';
$_['text_week']                  = 'týždeň';
$_['text_semi_month']            = 'pol-mesiac';
$_['text_month']                 = 'mesiac';
$_['text_year']                  = 'rok';

// Column
$_['column_name']                = 'Názov produktu';
$_['column_model']               = 'Model';
$_['column_quantity']            = 'Množstvo';
$_['column_price']               = 'Jednotková cena';
$_['column_total']               = 'Celkom';
