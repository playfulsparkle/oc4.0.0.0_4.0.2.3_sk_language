<?php
// Heading
$_['heading_title'] = 'Pokladňa';

// Text
$_['text_cart']     = 'Nákupný košík';
