<?php
// Text
$_['text_success']     = 'Úspech: Spustili ste %s cron úlohu!';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte povolenie na úpravu cron úloh!';
