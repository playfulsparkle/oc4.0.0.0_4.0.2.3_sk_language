<?php
// Text
$_['text_success']           = 'Úspech: Plán predplatného bol úspešne obnovený!';

// Error
$_['error_language']         = 'Upozornenie: Rozšírenie metódy platby sa nenašlo!';
$_['error_customer']         = 'Upozornenie: Rozšírenie metódy platby sa nenašlo!';
$_['error_product']          = 'Upozornenie: Rozšírenie metódy platby sa nenašlo!';
$_['error_shipping_address'] = 'Upozornenie: Rozšírenie metódy platby sa nenašlo!';
$_['error_shipping_method']  = 'Upozornenie: Metóda dopravy %s sa nenašla!';
$_['error_payment_address']  = 'Upozornenie: Rozšírenie metódy platby sa nenašlo!';
$_['error_payment_method']   = 'Upozornenie: Metóda platby %s sa nenašla!';
$_['error_extension']        = 'Upozornenie: Rozšírenie metódy platby sa nenašlo!';
$_['error_recurring']        = 'Upozornenie: Metóda platby nemá žiadne predplatné!';
