<?php
// Text
$_['text_upload']     = 'Váš súbor bol úspešne nahraný!';

// Error
$_['error_filename']  = 'Názov súboru musí mať medzi 3 a 64 znakmi!';
$_['error_file_type'] = 'Neplatný typ súboru!';
$_['error_upload']    = 'Nahranie súboru je povinné!';
