<?php
// Heading
$_['heading_title'] = 'Odhlásenie z účtu';

// Text
$_['text_message']  = '<p>Boli ste úspešne odhlásení z vášho účtu. Teraz je bezpečné opustiť počítač.</p><p>Vaša nákupná taška bola uložená a položky v nej budú obnovené, keď sa znova prihlásite do svojho účtu.</p>';
$_['text_account']  = 'Účet';
$_['text_logout']   = 'Odhlásiť sa';
