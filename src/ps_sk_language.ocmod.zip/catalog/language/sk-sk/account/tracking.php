<?php
// Heading
$_['heading_title']    = 'Sledovanie partnerov';

// Text
$_['text_account']     = 'Účet';
$_['text_description'] = 'Aby sme zabezpečili, že dostanete platbu za odporúčania, ktoré nám posielate, musíme sledovať odporúčanie umiestnením sledovacieho kódu do URL odkazujúcich na nás. Môžete použiť nástroje nižšie na generovanie odkazov na webovú stránku %s.';

// Entry
$_['entry_code']       = 'Váš sledovací kód';
$_['entry_generator']  = 'Generátor sledovacích odkazov';
$_['entry_link']       = 'Sledovací odkaz';

// Help
$_['help_generator']   = 'Zadajte názov produktu, na ktorý chcete vytvoriť odkaz';
