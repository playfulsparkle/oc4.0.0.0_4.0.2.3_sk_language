<?php
// Heading 
$_['heading_title']    = 'Odber noviniek';

// Text
$_['text_account']     = 'Účet';
$_['text_newsletter']  = 'Novinky';
$_['text_success']     = 'Vaše prihlásenie k odberu bolo úspešne aktualizované!';

// Entry
$_['entry_newsletter'] = 'Prihlásiť sa k odberu';