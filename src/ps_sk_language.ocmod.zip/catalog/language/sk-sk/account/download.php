<?php
// Heading
$_['heading_title']     = 'Súbory na stiahnutie';

// Text
$_['text_account']      = 'Účet';
$_['text_downloads']    = 'Sťahovanie';
$_['text_no_results']   = 'Nemáte žiadne predchádzajúce objednávky na stiahnutie!';

// Column
$_['column_order_id']   = 'ID objednávky';
$_['column_name']       = 'Názov';
$_['column_size']       = 'Veľkosť';
$_['column_date_added'] = 'Dátum pridania';

// Error
$_['error_not_found']    = 'Chyba: Súbor %s sa nenašiel!';
$_['error_headers_sent'] = 'Chyba: Hlavičky boli už odoslané!';
