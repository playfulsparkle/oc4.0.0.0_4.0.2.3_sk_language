<?php
// Heading
$_['heading_title']      = 'Vaše vernostné body';

// Column
$_['column_date_added']  = 'Dátum pridania';
$_['column_description'] = 'Popis';
$_['column_points']      = 'Body';

// Text
$_['text_account']       = 'Účet';
$_['text_reward']        = 'Vernostné body';
$_['text_total']         = 'Celkový počet vašich vernostných bodov je:';
$_['text_no_results']    = 'Nemáte žiadne vernostné body!';
