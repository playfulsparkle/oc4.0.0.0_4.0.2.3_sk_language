<?php
// Heading
$_['heading_title']      = 'Vaše transakcie';

// Column
$_['column_date_added']  = 'Dátum pridania';
$_['column_description'] = 'Popis';
$_['column_amount']      = 'Suma (%s)';

// Text
$_['text_account']       = 'Účet';
$_['text_transaction']   = 'Vaše transakcie';
$_['text_total']         = 'Váš aktuálny zostatok je:';
$_['text_no_results']    = 'Nemáte žiadne transakcie!';
