<?php
// Heading
$_['heading_title'] = 'Požadovanú stránku nie je možné nájsť!';

// Text
$_['text_error']    = 'Požadovanú stránku nie je možné nájsť.';