<?php
// Text
$_['text_project']       = 'Úvodná stránka projektu';
$_['text_documentation'] = 'Dokumentácia';
$_['text_support']       = 'Fórum podpory';
$_['text_footer']        = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Všetky práva vyhradené.';