<?php
// Text
$_['text_name']       = 'Slovenčina';
$_['text_loading']    = 'Načítava sa...';

// Button
$_['button_continue'] = 'Pokračovať';
$_['button_back']     = 'Späť';

// Error
$_['error_exception'] = 'Chyba číslo (%s): %s v %s na riadku %s';